# CTI-110
# P3HW1 - Debugging
# Mali Kane
# 10/26/2022
#

#Create a grade list of grades 
#User put float for grades
#User display the lowest grades in minimun grade and highest in maximun grade
#User display sum of grade in the output
#User add the average of grade to display that 
#User use a format to make the ouput perfectly aligne
#User use the if elif else to determine the grade

#Input
grades = [ ]

grades.append(float(input('Enter grade for Module 1:')))
grades.append(float(input('Enter grade for Module 2:')))
grades.append(float(input('Enter grade for Module 3:')))
grades.append(float(input('Enter grade for Module 4:')))
grades.append(float(input('Enter grade for Module 5:')))
grades.append(float(input('Enter grade for Module 6:')))

#Process
lowest_Grade = min(grades)
lighest_Grade = max(grades)
sum_Grade = sum(grades)
average = sum(grades)/len(grades)


#Output
print()
print('------------Results------------')
print(f'Lowest Grade:      ',min(grades))
print(f'Highest Grade:     ',max(grades))
print(f'Sum of Grade:      ',sum(grades))
print(f'Average:           ',(f'{sum(grades)/len(grades):.2f}'))
print('-------------------------------------------------')

#Detemine the grade 
if average >= 90:
     print('Your grade is: A')
     
elif average >= 80:
       print('Your grade is: B')
       
elif average >= 70:
       print('Your grade is: C')
       
else:
    print('Your grade is: D')
    
