# This programm calculates and displays travel expenses
# 09/26/2022
# CTI-110 P1HW2 - Travel Expense
# Mali Kane
#

# Create the variable to enter the amount of the budget
# User put int for numerical value
# User add expenses 
# User remains expenses to the budget
# User will display the amount 

#Input
budget = int(input('Enter budget:'))

destination = input('Enter your travel destination:')

gas = int(input('How much will you spend on gas?'))

accomodation = int(input('Aproximately how much will you spend on accomodation/hotel?'))

food = int(input('Last, how much do you need for food?'))

#Process
expenses = gas + accomodation + food

remains =budget - expenses


#Output

print('------------Travel Expenses------------')
print('Location:', destination)
print('Initial Budget:', budget)
print()
print('Fuel:', gas)
print('Accomodation:', accomodation)
print('Food:', food)
print()
print('Remains Blance:', remains)

