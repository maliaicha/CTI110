#CTI110
#P4LABa Shapes
#MALI KANE
#11/07/2022

import turtle             
win = turtle.Screen()
kane = turtle.Turtle()    

kane.pensize(4)            
kane.pencolor("pink")     
kane.shape("turtle")

#square
for i in range(4):
    kane.forward(50)
    kane.left(90)

#Move
kane.penup()
kane.forward(100)
kane.pendown()

#triangle
for i in range(3):
    kane.forward(100)
    kane.left(120)

win.mainloop()









