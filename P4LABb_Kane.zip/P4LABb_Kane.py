#CTI110
#P4LABb Initial
#MALI KANE
#11/07/2022


import turtle          
win = turtle.Screen()
kane = turtle.Turtle()

kane.pensize(5)            
kane.pencolor("purple")     
kane.shape("turtle")

#Start "M"
kane.right(90)
kane.forward(150)
kane.backward(150)
kane.left(45)
kane.forward(90)
kane.left(95)
kane.forward(90)
kane.right(140)
kane.forward(150)

kane.penup()
kane.left(150)
kane.forward(180)
kane.pendown()


#Start "K"
kane.right(150)
kane.forward(150)
kane.backward(75)
kane.left(50)
kane.forward(100)
kane.backward(100)
kane.left(80)
kane.forward(100)

kane.penup()
kane.right(180)
kane.forward(180)
kane.pendown()

#circle
radius = 10

for i in range(1):
    kane.circle(radius)
    

win.mainloop()






