# This programm calculates and displays travel expenses
# 10/10/2022
# CTI-110 P2HW1 - Travel
# Mali Kane
#


# Create the variable to enter the amount of the budget
# User put float for numerical value
# User add expenses
# User remains expenses to the budget
# User use a format tp propely aligne output 
# User use a dollar signe to make it appear before amounts
# User will display the amount

#Input
budget = float(input('Enter budget:'))

destination = input('Enter your travel destination:')

gas = float(input('How much will you spend on gas?'))

accomodation = float(input('Aproximately how much will you spend for accomodation/hotel?'))

food = float(input('Last, how much do you need for food?'))


#Process
expenses = gas + accomodation + food

remains =budget - expenses

#Output
print()
print('------------Travel Expenses------------')
print(f'Location:           {destination}')
print(f'Initial Budget:     ${budget}')
print(f'Fuel:               ${gas}')
print(f'Accomodation:       ${accomodation}')
print(f'Food:               ${food}')
print('---------------------------------------')
print()
print(f'Remaining Balance:  ${remains}')

