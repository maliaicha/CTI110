# CTI-110
# P2HW2 - List
# Mali Kane
# 11/14/2022
#

#This programm collect score from user
#User enter number of score he want to enter
#User create a loop to collect number of score
#User ask to enter a valid score to the list if is valid add to the list
#User display lowest score, modified list, average of score and letter of grade 

num_score = int(input('How many score do you want to enter?'))
print()

score_list = []

for i in range(1, num_score +1):
    score = int(input('Enter score #{}: '.format(i)))

    if score >= 0 and score <=100:
        score_list.append(score)
     
    else:
        print('INVALID score entered!!! \n Score should be between 0 and 100')
        score = int(input("Enter score #" +str(i)+" again: "))
        

min_score = min(score_list)
score_list.remove(min_score)
sum_score = sum(score_list)


print()
print('-------------Results-------------')
print('Lowest Score  :' , min(score_list))
print('Modified List :' ,(score_list))
print('Score Average :' , (f'{sum(score_list)/len(score_list):.2f}'))


average = (f'{sum(score_list)/len(score_list):.2f}')
if average >= '90':
     print('Your grade is: A')
     
elif average >= '80':
       print('Your grade is: B')
       
elif average >= '70':
       print('Your grade is  : C')
       
elif average >= '60':
    print('Your grade is: D')
    
else:
    print('Your grade is: F')
    

        

