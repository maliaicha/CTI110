# CTI-110
# P3HW2 - Salary
# Mali Kane 
# 11/31/2022
#

#User set global variables
#User run a loop until he want to exit
#User enter employee's name, hours worked, and pay rate
#User enter "None", then break the loop without any further user input
#User calcul overtime, overtime pay, regular pay, and gross pay
#User add overtime pay to have a  total overtime pay
#User dispay overtime total , regular pay total ,gross pay total and number of employees entered


numOfEmp = 0               # holds total employees entered
totalOverTimePay = 0       # holds total over time pay for all employees
totalRegPay = 0            # holds total regular pay for all employees
totalGrossPay = 0          # holds total gross pay for all employees


while True:
    name = input("Enter employee's name or \"None\" to terminate: ")
    
    if name == "None":
        break
    
    else:
        numOfEmp += 1
        hours = float(input("How many hours did " + name + " worked? "))
        rate = float(input("What did " + name + "\'s pay rate? "))
    
    
    overtime = 0
    overtimePay = 0
    regularPay = 0
    grossPay = 0
    
   
    if hours > 40:
        overtime = hours - 40
        overtimePay = overtime * rate * 1.5
        regularPay = 40*rate
        grossPay = regularPay + overtimePay
        
    else:
        regularPay = hours*rate
        grossPay = regularPay
    
    totalOverTimePay += overtimePay
    totalRegPay += regularPay
    totalGrossPay += grossPay
    
    print("\nEmployee name: " + name + "\n")
    
    print("{:<20}{:<20}{:<20}{:<20}{:<20}{:<20}".format("Hours Worked", "Pay Rate", "OverTime", "OverTime Pay", "RegHour Pay", "Gross Pay"))
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("{:<20.1f}{:<20.1f}{:<20.1f}{:<20.2f}${:<19.2f}${:<20.2f}".format(hours, rate, overtime, overtimePay, regularPay, grossPay))
    print()

print()
print("Total number of employees entered:", numOfEmp)
print("Total amount payed for over time: $" + '{:.2f}'.format(totalOverTimePay))
print("Total amount payed for regular hours: $" + '{:.2f}'.format(totalRegPay))
print("Total amount payed in gross: $" + '{:.2f}'.format(totalGrossPay))
