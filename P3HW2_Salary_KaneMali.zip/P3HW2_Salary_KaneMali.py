# CTI-110
# P3HW2 - Salary
# Mali Kane 
# 11/31/2022
#


# User enter the name of employee
# User enter the number of hours the employee worked this month
# User enter employee's pay rate
# User Calculate amount employee shoud be paid for regular hours worked.
# User Display gross pay 
# Display employee name pay rate, number of hours worked, overtime hours, overtime pay , pay for regular hours and gross pay


#Input
name = input("Enter emloyee's name:")
hours_worked = float(input("Enter number of hours worked:"))
pay_rate = float(input("Enter emloyee's pay rate:"))                     

#Process
if hours_worked > 40:
   overtime = hours_worked - 40
   overtimeformula = pay_rate * 1.5
   overtimepay = overtime * overtimeformula
   reghourpay = (hours_worked - overtime) * pay_rate
   grosspay = overtimepay + reghourpay  
   

else:
   gross_pay = hours_worked * pay_rate
   
   

#Output
print('---------------------------------------')
print(f'Employee name:     {name}')
print()
print('Hours Worked      Pay Rate      OverTime      OverTime Pay         RegHour Pay       Gross Pay')
print('---------------------------------------------------------------------------------------------------------')
print(f'{hours_worked}              {pay_rate}          {overtime}           {overtimepay:.2f}               ${reghourpay:.2f}            ${grosspay}')
