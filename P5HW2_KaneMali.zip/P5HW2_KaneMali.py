# 11/28/2022
# CTI-110
# P5HW2 - Math Quiz
# Mali Kane
#

#User generate a randoms number and return it 
#User use loop to checks wheter the guess made is correct
#User use function definition to to name the function 
#User add a function that add, sustracts randondom number 
#User can exist if he want by choosing that option
#Display the menu and read choice from user 


import random


def generateRandomNo():
    return random.randint(10, 99)

def checkGuess(number, guess):
    if guess < number :
        print('Sorry, guess is too low.')
        return 0
    elif guess > number:
        print('Sorry, guess is too high.')
        return 0
    else: 
        print('Congratulations!!!! your answer is correct..')
        return 1
        
def main():
    print('Welcome to Math Quiz')
    while True:
        choice = menu()
        if choice == 1:
            a = generateRandomNo()
            b = generateRandomNo()
            print("  "+ str(a) + "\n+ " + str(b))
            ans = a + b
            guess = int(input('Enter answer.\n'))
            i = 1
            while(checkGuess(ans, guess) != 1 ):
                guess = int(input('try again: '))  
                i = i + 1
            print('Number of guesses: '+str(i))
        elif choice == 2:
            a = generateRandomNo()
            b = generateRandomNo()
            print("  "+ str(a) + "\n- " + str(b))
            ans = a - b
            guess = int(input('Enter answer.\n'))
            i = 1
            while(checkGuess(ans, guess) != 1 ):
                guess = int(input('try again: '))  
                i = i + 1
            print('Number of guesses: '+str(i))
        elif choice == 3:
            print('Thank you for playing...')
            print('Bye!!')
            break
        else:
            print("Invalid option... Try again")
            
        
def menu():
    print()
    print('MAIN MENU')
    print('-----------------')
    print('1. Adding Random Numbers')
    print('2. Subtracting Random Numbers')
    print('3. Exit')
    print()
    choice = int(input('Please choose one of the menu options: '))
    return choice

main()
