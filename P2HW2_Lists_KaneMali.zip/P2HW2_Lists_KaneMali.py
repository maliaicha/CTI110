# CTI-110
# P2HW2 - List
# Mali Kane
# 10/05/2022
#

#Create a grade list of grades 
#User put float for grades
#User display the lowest grades in minimun grade and highest in maximun grade
#User display sum of grade in the output
#User add the average of grade to display that 
#User use a format to make the ouput perfectly aligne

#Input
grades = [ ]

grades.append(float(input('Enter grade for Module 1:')))
grades.append(float(input('Enter grade for Module 2:')))
grades.append(float(input('Enter grade for Module 3:')))
grades.append(float(input('Enter grade for Module 4:')))
grades.append(float(input('Enter grade for Module 5:')))
grades.append(float(input('Enter grade for Module 6:')))


#Process


#Output
print()
print('------------Results------------')
print(f'Lowest Grade:      ',min(grades))
print(f'Highest Grade:     ',max(grades))
print(f'Sum of Grade:      ',sum(grades))
print(f'Average:           ',(f'{sum(grades)/len(grades):.2f}'))
print('-------------------------------------------------')





